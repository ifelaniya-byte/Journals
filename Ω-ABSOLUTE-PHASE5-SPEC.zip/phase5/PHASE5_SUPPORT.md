# Phase 5 Support

**Change Control**: previous 0.5.0 → new 0.6.0-verification  
**Claim Discipline**: “Verification hierarchy applied; verifier cannot verify itself; critique depth bounded; debate is evidence generation only.”  
**Release gate**: hierarchy tests + adversarial bypass attempts defeated + Gap Matrix updated.
