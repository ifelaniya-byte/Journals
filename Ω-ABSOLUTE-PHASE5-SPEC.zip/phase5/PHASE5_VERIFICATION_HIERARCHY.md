# Ω-ABSOLUTE — Phase 5 Specification
## Verification Hierarchy

**Document status**: SPECIFIED (not yet implemented)  
**Target release**: v0.6.0-verification  
**Canonical sections**: §§30–35  
**Parent**: Phases 0–4

---

## 0. PURPOSE

Phase 5 installs the adversarial and hierarchical verification machinery that prevents solvers from optimizing against weak evaluators and that keeps every consequential result auditable.

Systems:

- Verification Engine (§30)
- Red Team (§31)
- Verifier-of-Verifiers (§32)
- Recursive Critique (§33) — with mandatory termination policy
- Debate / Cross-Examination (§34)
- Evidence / Proof Graph (§35)

**Non-claims**:
- Verification does not equal universal correctness.
- A verifier must never silently verify itself (INVARIANT_006).
- Majority agreement is never treated as proof (INVARIANT_017).
- Recursive critique must terminate by marginal expected value (INVARIANT_018).

---

## 1. VERIFICATION ENGINE (§30)

Inspects as many of the following as practical:

- inputs, assumptions, intermediate states, tools, evidence
- reasoning artifacts, final result, constraints, execution trace

Independent methods preferred when available.

**Interface**:
```
verify(target, methods, depth) → VerificationRecord
```

---

## 2. RED TEAM (§31)

Every consequential solution receives adversarial analysis targeting:

- counterexamples, hidden assumptions, causal errors
- logical contradictions, missing variables, bad evidence
- tool failures, edge cases, resource failures
- specification exploits, verification exploits

---

## 3. VERIFIER-OF-VERIFIERS (§32)

```
SOLVER → VERIFIER → VERIFIER_CRITIC → VERIFICATION_AUDITOR
```

Purpose: reduce the risk that the solver optimizes against a weak evaluator.  
The hierarchy is already declared immutable in the Ω Core; Phase 5 implements the stages.

---

## 4. RECURSIVE CRITIQUE (§33)

```
answer → critique → critique_of_critique → additional audit
```

**Hard rule**: recursion terminates according to marginal expected value.  
Infinite self-critique is prohibited. Resource ceiling `max_recursive_critique_depth` (already in Core) is enforced.

---

## 5. DEBATE / CROSS-EXAMINATION (§34)

When independent solvers disagree:

1. Identify disagreement  
2. Identify differing premises  
3. Identify differing predictions  
4. Search for discriminating evidence  
5. Experiment / retrieve / verify  

Debate generates evidence; it is not truth by majority vote.

---

## 6. EVIDENCE / PROOF GRAPH (§35)

Every consequential conclusion carries:

```
conclusion
  ├── premise → source
  ├── evidence
  ├── inference
  ├── experiment
  ├── counterexample_tests
  └── independent_verification
```

Enables full provenance auditing.

---

## 7. INTEGRATION

```
SimulationInterventionResult (or any consequential candidate)
  → Verification Engine
  → Red Team
  → Verifier-of-Verifiers audit
  → optional Recursive Critique (bounded)
  → optional Debate if solvers disagree
  → Evidence/Proof Graph attachment
  → VerificationHierarchyResult
```

---

## 8. SCHEMAS (spec/phase5/)

- verification_record.schema.json (extends foundation)
- red_team_finding.schema.json
- verifier_audit.schema.json
- critique_node.schema.json
- debate_record.schema.json
- evidence_graph.schema.json
- verification_hierarchy_result.schema.json

---

## 9. KEY INVARIANTS

- 005 Solver output ≠ verified output  
- 006 Verifier must not silently verify itself  
- 017 Majority ≠ proof  
- 018 Recursive critique terminates  

---

## 10. TEST PLAN (high level)

- Hierarchy stages are distinct and ordered.
- Self-verification attempts are rejected.
- Critique depth ceiling is enforced.
- Debate records disagreement without declaring majority truth.
- Evidence graphs preserve full provenance.
- Adversarial suite attempts to bypass or weaken the verifier.

---

## 11. OUT OF SCOPE

Failure diagnosis loops, memory architecture, capability mutation/promotion, meta-experimentation, final Master Loop wiring.

**END OF PHASE 5 SPECIFICATION**
