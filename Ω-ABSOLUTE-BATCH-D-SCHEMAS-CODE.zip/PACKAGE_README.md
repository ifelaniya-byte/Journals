# Batch D — Schemas, Gap Matrices, Foundation Code

Upload AFTER Batches A–C.

Contains:
- spec/          (all JSON schemas: foundation + phase1 + supporting)
- artifacts/     (all gap-matrix snapshots)
- runtime/       (Ω Core, governance, telemetry, placeholders)
- tests/         (unit tests)
- omega.py, requirements.txt, .gitignore, README.md

Does NOT contain the phase specification markdown (those are Batches B/C).

Parent: v0.1.0-foundation code + all schemas produced during specification.
