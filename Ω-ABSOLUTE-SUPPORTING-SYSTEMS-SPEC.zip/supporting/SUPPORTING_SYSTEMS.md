# Ω-ABSOLUTE — Supporting Systems Specification
## Operational Substrate for Full Functionality

**Document status**: SPECIFIED (not yet implemented)  
**Parent releases**: v0.1.0-foundation + Phases 1–7 (all specified)  
**Target label**: `v1.0.0-supporting` / architectural completeness + operability  
**Canonical anchors**: §§4, 18–22, 26–30, 39, 46–47, 55–58, 71, 75–77  
**Governing Core**: Immutable Ω Core (INVARIANT_013)

---

## 0. PURPOSE

Phases 0–7 define every cognitive and governance subsystem required by the canonical architecture.  
This document defines the **operational substrate** those subsystems assume but do not themselves specify:

| ID | Supporting System                         | Primary need |
|----|-------------------------------------------|--------------|
| S1 | Tool Runtime & Registry                   | Safe, provenance-bearing tool use |
| S2 | Bounded Execution Substrate               | Controlled running of code, tools, interventions |
| S3 | Persistence & Memory Store                | Durable episodic/semantic/procedural/counterfactual memory + Capability Graph |
| S4 | Authorization & Human-in-the-Loop         | Explicit approval for irreversible / high-risk actions |
| S5 | Benchmark & Evaluation Harness            | Concrete meaning for “benchmarked” and “reproduced” |
| S6 | Seed Capability Set                       | Non-empty starting competence |
| S7 | Observability & Reconstruction Pack       | Full tracing + artifacts another AI needs to reconstruct the system |

After this package is implemented and verified, the system can be built, run, measured, authorized, and reconstructed end-to-end.

**Non-claims**:
- These systems do not add new cognitive engines.
- They do not relax any Core safety boundary.
- They do not claim task-solving power by themselves.

---

## S1. TOOL RUNTIME & REGISTRY

### Purpose
Provide a single, governed interface through which any capability or solver may invoke external tools.

### Requirements
- **Registry**: every tool has a unique ID, version, input/output schema, resource estimate, risk class, and provenance.
- **Invocation**: `tool.call(tool_id, args, context) → ToolResult` with full telemetry and provenance.
- **Sandboxing**: tools run under the same resource ceilings and reversibility rules as the rest of the system.
- **Authorization**: tools marked IRREVERSIBLE or HIGH_RISK require S4 approval before execution.
- **Failure isolation**: tool crashes or timeouts must not corrupt Core or memory state.
- **Provenance**: every ToolResult carries a ProvenanceRecord (source_type = TOOL).

### Minimal interface
```
tool.register(spec) → tool_id
tool.list(filter) → list[ToolSpec]
tool.call(tool_id, args, budget, auth_token?) → ToolResult
tool.revoke(tool_id)  # governed by Core
```

### Schema
`spec/supporting/tool_spec.schema.json`, `tool_result.schema.json`

---

## S2. BOUNDED EXECUTION SUBSTRATE

### Purpose
The actual process that executes code, tool calls, simulations, and interventions while respecting Core ceilings and reversibility.

### Requirements
- Hard enforcement of: max_tokens, max_wall_time, max_tool_calls, max_memory, max_recursive_critique_depth.
- Process / container isolation for untrusted code.
- Explicit mode flags: SIMULATED | SANDBOXED | REVERSIBLE_TEST | REAL.
- Every execution produces an ExecutionTrace (inputs, outputs, resource_usage, error_state, provenance).
- REAL mode for irreversible actions is unreachable without a valid S4 authorization token.
- Deterministic replay support where the underlying tools allow it (feeds ReproducibilityRecord).

### Minimal interface
```
exec.run(plan, mode, budget, auth_token?) → ExecutionTrace
exec.replay(trace_id) → ExecutionTrace   # best-effort
```

### Schema
`execution_trace.schema.json`, `execution_budget.schema.json`

---

## S3. PERSISTENCE & MEMORY STORE

### Purpose
Durable storage for the four memory classes (§39), the Capability Graph (§19), Failure Memory (§38), Versioned Self (§53), and Reproducibility Ledger (§58).

### Requirements
- Separate logical stores (or clearly namespaced collections) for:
  - Episodic, Semantic, Procedural, Counterfactual memory
  - Capability Graph nodes + edges
  - Failure records
  - Version records + rollback targets
  - Reproducibility ledger entries
- Every write carries provenance and confidence.
- Reads are filtered by epistemic state when requested.
- Versioning / snapshot support so rollback can restore a prior Capability Graph or Self Model.
- No silent deletion of CONTRADICTED / DISPROVEN claims or failure lessons (INVARIANT_015).
- Export format sufficient for S7 reconstruction.

### Minimal interface
```
store.put(collection, key, record)
store.get(collection, key) → record | None
store.query(collection, filter) → list[record]
store.snapshot(label) → snapshot_id
store.restore(snapshot_id)  # governed, used by Rollback
```

### Schema
`memory_record.schema.json`, `capability_graph_snapshot.schema.json`, `store_snapshot.schema.json`

---

## S4. AUTHORIZATION & HUMAN-IN-THE-LOOP

### Purpose
Satisfy the Core safety boundary “no irreversible action without authorization.”

### Requirements
- Explicit AuthorizationRequest containing: action description, reversibility class, risk assessment, expected gain/loss, evidence summary, timeout.
- Human or designated external authority returns: APPROVED | REJECTED | DEFERRED + optional constraints.
- Authorization tokens are single-use or time-bounded and scoped to a specific action hash.
- All requests and decisions are logged with provenance and appear in the audit trail.
- System must be able to continue safe work (simulation, reversible tests, information gathering) while waiting.
- Default under timeout or missing authority: REJECT (fail-safe).

### Minimal interface
```
auth.request(action_descriptor) → request_id
auth.status(request_id) → PENDING | APPROVED | REJECTED | DEFERRED
auth.token(request_id) → scoped_token | None
```

### Schema
`authorization_request.schema.json`, `authorization_decision.schema.json`

---

## S5. BENCHMARK & EVALUATION HARNESS

### Purpose
Give concrete, reproducible meaning to the DevelopmentState values BENCHMARKED, VERIFIED, and to the promotion gate’s RESOURCE / REPRODUCTION / TRANSFER tests.

### Requirements
- Versioned benchmark suites (task sets + metrics + expected resource envelopes).
- Standard metrics: solution quality, calibration, robustness under distribution shift, resource cost, transfer success rate.
- Automatic production of ReproducibilityRecords.
- Ablation and adversarial variants of each suite.
- Leaderboard / history store that itself carries provenance (no silent overwrites).
- Clear separation between “benchmark passed” and “safe for promotion.”

### Minimal interface
```
bench.register_suite(suite_spec)
bench.run(suite_id, system_under_test, config) → BenchmarkReport
bench.compare(report_a, report_b) → DeltaReport
```

### Schema
`benchmark_suite.schema.json`, `benchmark_report.schema.json`

---

## S6. SEED CAPABILITY SET

### Purpose
Ensure the system is not empty on first launch. Provide a minimal, fully gated set of capabilities so Meta-Controller and Capability Gap Engine have something to reason over.

### Required seed capabilities (illustrative minimum)
1. `seed.identity` — returns Core identity and version (already present).
2. `seed.echo_task_model` — builds a trivial TaskModel from raw text (depends on Phase 1).
3. `seed.epistemic_tag` — attaches HYPOTHESIZED/UNKNOWN to free-text claims.
4. `seed.retrieve_local` — searches local memory / docs with provenance.
5. `seed.simulate_noop` — runs a null simulation that returns SIMULATED flag.
6. `seed.verify_schema` — checks that a Result object conforms to the canonical schema.
7. `seed.fail_closed` — explicit safe failure capability used when gaps cannot be filled.

All seed capabilities ship at DevelopmentState = TESTED (or VERIFIED if the full gate is run) and appear in the initial Capability Graph and Self Model.

### Schema
`seed_capability_manifest.schema.json`

---

## S7. OBSERVABILITY & RECONSTRUCTION PACK

### Purpose
Satisfy §57 (Observability) at full Master-Loop scale and §75–77 (another AI can reconstruct the system from the repository alone).

### Requirements

**Observability**
- Structured trace spanning every Master Loop step (trace_id, parent_span, subsystem, action, resource_usage, epistemic tags, error_state).
- Correlation of tool calls, simulations, verifications, and authorization decisions under one trace_id.
- Exportable in a standard format (e.g. JSON lines or OpenTelemetry-compatible).

**Reconstruction Pack** (the exact artifact set a receiving AI needs)
1. Canonical specification (`docs/Ω-ABSOLUTE.md`)
2. All phase specifications + this supporting-systems document
3. Foundation freeze + Gap Matrix snapshots
4. Complete source tree at a tagged release
5. Schema set
6. Seed capability manifest
7. Benchmark suite definitions
8. Latest ReproducibilityRecords for promoted components
9. CHANGELOG + ROADMAP
10. One end-to-end successful `omega.solve` trace (anonymized if necessary)

A receiving AI following §75 must be able to rebuild the system and re-run the seed benchmarks from this pack alone.

### Schema
`trace_span.schema.json`, `reconstruction_manifest.schema.json`

---

## INTEGRATION WITH EXISTING PHASES

```
omega.solve(task)
  → (Phases 1–7 cognitive path)
  → tool calls go through S1
  → execution goes through S2
  → memory / graph reads-writes go through S3
  → irreversible steps require S4 token
  → promotion / claims checked against S5 reports
  → initial competence comes from S6
  → every step emits S7 traces
  → final Result object + Reconstruction Pack artifacts
```

The Immutable Ω Core remains the sole authority over ceilings, promotion gates, and irreversible-action policy. Supporting systems implement; they never redefine those rules.

---

## CHANGE CONTROL (template)

```
previous_version : v1.0.0 (Phase 7) or latest phase tag
new_version      : v1.0.0-supporting
reason           : Supply operational substrate required for end-to-end functionality
expected_gain    : Runnable, measurable, authorizable, reconstructible system
expected_risk    : Medium (execution surface); mitigated by Core ceilings + S4 fail-closed default
test_plan        : Unit tests per subsystem + one end-to-end solve using only seed capabilities
rollback_plan    : Revert to previous tag; supporting modules are additive
```

---

## COMPLETION CRITERION

Supporting Systems are complete when:

1. All seven subsystems are implemented and unit-tested.
2. An end-to-end `omega.solve` on a seed task succeeds under resource ceilings.
3. At least one irreversible-action path correctly blocks without S4 token and succeeds with a valid token.
4. A full Reconstruction Pack is generated and an independent process can rehydrate the system from it.
5. Gap Matrix shows no critical supporting component left at NOT_DESIGNED.
6. ChangeControlRecord is APPLIED and the release is tagged.

At that point the specification side of Ω-ABSOLUTE is sufficient for a full functional build.

**END OF SUPPORTING SYSTEMS SPECIFICATION**
