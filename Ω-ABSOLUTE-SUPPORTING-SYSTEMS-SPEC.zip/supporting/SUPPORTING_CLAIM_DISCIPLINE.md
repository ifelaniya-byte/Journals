# Supporting Systems — Claim Discipline

Allowed after implementation + tests:
- “Tool runtime registered and ceiling-enforced.”
- “Execution substrate respects REAL-mode authorization gate.”
- “Memory and Capability Graph persist with provenance.”
- “Irreversible actions blocked without authorization token.”
- “Benchmark harness produces ReproducibilityRecords.”
- “Seed capabilities present and gated.”
- “Reconstruction pack sufficient for independent rehydration.”

Forbidden:
- Claiming any supporting system grants task-solving power by itself.
- Claiming REAL execution is safe without S4.
- Claiming reconstruction works without the full pack listed in S7.
