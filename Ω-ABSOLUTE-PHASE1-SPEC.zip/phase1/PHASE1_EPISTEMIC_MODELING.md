# Ω-ABSOLUTE — Phase 1 Specification
## Epistemic & Modeling Core

**Document status**: SPECIFIED (not yet implemented)  
**Parent release**: v0.1.0-foundation  
**Target release**: v0.2.0-epistemic-modeling  
**Canonical parent**: docs/Ω-ABSOLUTE.md (Version 1.0 — Frozen Theoretical Architecture)  
**Governing Core**: Immutable Ω Core (INVARIANT_013)

---

## 0. PURPOSE OF THIS PHASE

Phase 1 constructs the first cognitive layer that the Meta-Controller can invoke.

It implements, under Core governance:

- Epistemic Engine (§7)
- Task Model (§6)
- World Model (§8)
- Self Model (§9)
- Rule-Space Compiler (§10)

After Phase 1, every incoming task can be transformed into an explicit, epistemically tagged, self-aware, rule-compiled model before any solver, simulation, or verification is attempted.

**Non-claims** (Claim Discipline §62):

- Phase 1 does **not** solve tasks.
- Phase 1 does **not** implement causal reasoning, counterfactuals, capability synthesis, verification, or the Master Solving Loop.
- Phase 1 produces structured models and epistemic records only.
- No component may claim “verified world model” or “verified self-model” until the corresponding tests and reproduction records exist.

---

## 1. DEPENDENCIES ON FOUNDATION

Phase 1 may use, but must never modify:

| Foundation component          | Usage in Phase 1                                      |
|-------------------------------|-------------------------------------------------------|
| OmegaCore                     | Governance, ceilings, promotion gates, boundaries     |
| ClaimDiscipline               | All new claims checked before emission                |
| ProvenanceRecord              | Every fact, inference, and model carries provenance   |
| ChangeControlRecord           | This phase itself and every later change              |
| ReproducibilityRecord         | Required for any promotion of Phase-1 components      |
| GapMatrix                     | Updated as each engine advances                       |
| Telemetry / ResourceTracker   | All operations emit telemetry and respect ceilings    |
| MetaController                | Sole authorized invoker of Phase-1 engines            |

The Meta-Controller remains SCAFFOLDED; Phase 1 only expands the set of subsystems it is allowed to call.

---

## 2. EPISTEMIC ENGINE (§7)

### 2.1 Purpose

Every meaningful proposition that enters or is produced by the system MUST carry an explicit epistemic state.  
An inference MUST NOT silently become a verified fact (INVARIANT_003, INVARIANT_001).

### 2.2 Canonical Epistemic States

```
OBSERVED
VERIFIED
SUPPORTED
INFERRED
ASSUMED
HYPOTHESIZED
UNKNOWN
CONTRADICTED
DISPROVEN
STALE
```

These are already defined in `runtime/governance/states.py` (foundation). Phase 1 makes them operational.

### 2.3 Claim Record

Every proposition is stored as a Claim Record:

```
ClaimRecord
    claim_id            : UUID
    content             : str
    epistemic_state     : EpistemicState
    source              : str
    provenance          : list[ProvenanceRecord]
    confidence          : float          # [0.0, 1.0]
    evidence            : list[str]
    contradictions      : list[claim_id]
    recency             : datetime
    reproducibility     : optional[ReproducibilityRecord]
    causal_relevance    : optional[float]
    verification_state  : optional[str]
    parent_claims       : list[claim_id]
    derived_from        : list[claim_id]
    tags                : list[str]
```

### 2.4 Core Rules

1. A new ClaimRecord defaults to HYPOTHESIZED or UNKNOWN unless evidence justifies a stronger state.
2. Transition to VERIFIED requires independent verification evidence and a ReproducibilityRecord marked REPRODUCED (or an explicit Core-authorized exception for pure logical tautologies).
3. MODEL_INFERENCE provenance may never produce a VERIFIED state by itself.
4. STALE is set when the underlying evidence is older than a configurable horizon or when a contradicting claim of higher strength appears.
5. CONTRADICTED / DISPROVEN claims remain in the ledger; they are never silently deleted (provenance survival — INVARIANT_015).

### 2.5 Public Interface (conceptual)

```
epistemic.assert(claim, evidence, provenance, suggested_state) → ClaimRecord
epistemic.query(filter) → list[ClaimRecord]
epistemic.contradict(claim_id, contrary_claim_id, evidence)
epistemic.reclassify(claim_id, new_state, justification, provenance)
epistemic.snapshot() → EpistemicStateSummary
```

All methods must emit TelemetryEvent and respect resource ceilings.

### 2.6 Development Target

| Stage            | Requirement                                      |
|------------------|--------------------------------------------------|
| DESIGNED         | This section                                     |
| SCAFFOLDED       | Data classes + empty methods                     |
| IMPLEMENTED      | Full assert/query/reclassify logic               |
| TESTED           | Unit tests for state transitions & invariants    |
| INTEGRATED       | Callable from Meta-Controller                    |
| VERIFIED         | Adversarial tests on silent-upgrade attempts     |

---

## 3. TASK MODEL (§6)

### 3.1 Purpose

Every incoming task MUST be transformed into an explicit Task Model before further processing.

### 3.2 Required Fields

```
TaskModel
    task_id             : UUID
    raw_input           : any
    objective           : str
    constraints         : list[Constraint]
    success_criteria    : list[Criterion]
    failure_criteria    : list[Criterion]
    stakeholders        : list[str]
    dependencies        : list[task_id | external_ref]
    subgoals            : list[Subgoal]
    resources           : ResourceEstimate
    deadlines           : optional[datetime]
    risk                : RiskAssessment
    reversibility       : ReversibilityClass   # REVERSIBLE | PARTIALLY_REVERSIBLE | IRREVERSIBLE
    verification_requirements : list[str]
    unknowns            : list[ClaimRecord]    # epistemic UNKNOWN / HYPOTHESIZED items
    epistemic_summary   : EpistemicStateSummary
    created_at          : datetime
    provenance          : list[ProvenanceRecord]
```

### 3.3 Derived Graphs

```
TASK
  ↓
TASK GRAPH          (nodes = subgoals / actions, edges = ordering)
  ↓
DEPENDENCY GRAPH    (hard prerequisites)
  ↓
SUBGOAL GRAPH       (hierarchical decomposition)
  ↓
EXECUTION PLAN      (ordered, resource-annotated steps)  [produced later by planning]
```

Phase 1 produces the Task Model and the first three graphs. The Execution Plan is only sketched; full planning belongs to a later phase.

### 3.4 Constraint & Criterion Types

- Soft / Hard constraints
- Quantitative / Qualitative success criteria
- Explicit failure criteria (what counts as “this task has failed”)

### 3.5 Public Interface

```
task_model.from_raw(raw_task, epistemic_engine) → TaskModel
task_model.decompose(task_id) → SubgoalGraph
task_model.update_unknowns(task_id, new_claims)
task_model.snapshot(task_id) → TaskModel
```

### 3.6 Development Target

Same staged progression as Epistemic Engine. Must refuse to emit a TaskModel that lacks success_criteria or that treats unknowns as known.

---

## 4. WORLD MODEL (§8)

### 4.1 Purpose

Represent the relevant external reality for a task:

- entities
- states
- variables
- relationships
- constraints
- resources
- events
- transitions
- observables
- hidden variables
- temporal structure

The system SHOULD maintain multiple competing models when uncertainty warrants them.

### 4.2 Structure

```
WorldModel
    model_id            : UUID
    task_id             : optional[UUID]      # may be task-specific or longer-lived
    entities            : dict[entity_id, Entity]
    relations           : list[Relation]
    constraints         : list[Constraint]
    observables         : list[Observable]
    hidden_variables    : list[HiddenVariable]
    temporal_structure  : optional[TemporalFrame]
    competing_models    : list[model_id]      # alternative hypotheses
    confidence          : float
    epistemic_state     : EpistemicState      # of the model as a whole
    provenance          : list[ProvenanceRecord]
    last_updated        : datetime
```

### 4.3 Construction Pipeline

```
observations
    + prior knowledge
    + inferred structure
    + experiments          (experiments themselves are Phase ≥2)
        ↓
candidate world models
```

Phase 1 supports construction from observations + prior knowledge + explicit inferences. Active experimentation is out of scope.

### 4.4 Rules

- A WorldModel whose epistemic_state is HYPOTHESIZED or INFERRED must never be treated as OBSERVED or VERIFIED by downstream code.
- Hidden variables remain probability distributions (or explicit UNKNOWN); they are never collapsed to point values without justification.
- Competing models are first-class; majority vote among them is evidence, not proof (INVARIANT_017 reserved for later).

### 4.5 Public Interface

```
world_model.create(task_id, observations, priors) → WorldModel
world_model.add_entity / add_relation / add_constraint
world_model.set_hidden(variable_id, distribution_or_unknown)
world_model.compete(model_id, alternative_model) → list[model_id]
world_model.snapshot(model_id) → WorldModel
```

---

## 5. SELF MODEL (§9)

### 5.1 Purpose

Ω MUST maintain an explicit model of its own capabilities so it can answer:

> “How reliable am I on this class of task?”

rather than assuming uniform competence.

### 5.2 Required Fields

```
SelfModel
    available_capabilities   : list[CapabilityRef]
    missing_capabilities     : list[CapabilityGap]
    capability_reliability   : dict[capability_id, ReliabilityRecord]
    model_reliability        : dict[model_type, float]
    memory_reliability       : float
    tool_reliability         : dict[tool_id, float]
    verifier_reliability     : float          # still low in Phase 1
    calibration_history      : list[CalibrationEvent]
    failure_history          : list[FailureRecord]
    known_weaknesses         : list[str]
    compute_budget           : ResourceCeilingView
    latency_budget           : float
    memory_budget            : float
    risk_budget              : float
    last_updated             : datetime
    provenance               : list[ProvenanceRecord]
```

### 5.3 Bootstrap at Phase 1

At the start of Phase 1 the Self Model knows only:

- the foundation capabilities (Core, governance, telemetry, Meta-Controller scaffold)
- that all higher cognitive engines are missing
- that its own reliability estimates are themselves HYPOTHESIZED

### 5.4 Public Interface

```
self_model.snapshot() → SelfModel
self_model.record_failure(failure_record)
self_model.record_calibration(event)
self_model.query_reliability(capability_or_class) → ReliabilityRecord
self_model.list_gaps() → list[CapabilityGap]
```

---

## 6. RULE-SPACE COMPILER (§10)

### 6.1 Purpose

For each sufficiently structured task, compile:

- objects
- states
- variables
- rules
- constraints
- transitions
- invariants
- dependencies
- conflicts
- failure_conditions

### 6.2 Rule Record

```
Rule
    rule_id             : UUID
    content             : str | structured
    confidence          : float
    provenance          : list[ProvenanceRecord]
    mutability          : FIXED | ASSUMED | UNCERTAIN | INTERVENABLE | UNKNOWN
    interventionability : bool
    dependencies        : list[rule_id]
    epistemic_state     : EpistemicState
```

### 6.3 Rule Classes (already in spirit of foundation states)

```
FIXED
ASSUMED
UNCERTAIN
INTERVENABLE
UNKNOWN
```

### 6.4 Public Interface

```
rule_space.compile(task_model, world_model) → RuleSpace
rule_space.query(filter) → list[Rule]
rule_space.conflicts() → list[Conflict]
```

---

## 7. INTEGRATION WITH META-CONTROLLER

Phase 1 extends the Meta-Controller’s allowed decision targets:

```
INVOKE_EPISTEMIC
INVOKE_TASK_MODEL
INVOKE_WORLD_MODEL
INVOKE_SELF_MODEL
INVOKE_RULE_SPACE
```

The Meta-Controller still does not perform full architecture search or solver population. It only sequences the modeling engines and respects Core safety boundaries.

Typical Phase-1 flow for an incoming task:

```
raw task
  → epistemic classification of all embedded claims
  → TaskModel construction (with unknowns preserved)
  → WorldModel construction (competing models if warranted)
  → SelfModel consultation (do we even have the required capabilities?)
  → RuleSpace compilation
  → return structured ModelingResult to caller
```

No execution, no verification beyond epistemic hygiene, no capability synthesis.

---

## 8. NEW SCHEMAS REQUIRED

Phase 1 introduces the following schema files (to be placed under `spec/phase1/`):

- claim_record.schema.json
- task_model.schema.json
- world_model.schema.json
- self_model.schema.json
- rule.schema.json
- modeling_result.schema.json

All must reference the foundation `omega.schema.json` definitions for EpistemicState, SourceType, etc.

---

## 9. INVARIANTS SPECIALLY RELEVANT TO PHASE 1

| ID  | Invariant                                      | Enforcement point                  |
|-----|------------------------------------------------|------------------------------------|
| 001 | Unknown ≠ known                                | Epistemic Engine, TaskModel        |
| 003 | Hypothesis ≠ fact                              | Epistemic Engine, WorldModel       |
| 004 | Implementation ≠ verification                  | ClaimDiscipline (already present)  |
| 015 | Provenance survives transformations            | All new records                    |
| 016 | No empirical success without execution         | No Phase-1 component may claim it  |

---

## 10. TEST PLAN (minimum before any promotion)

### Unit

- Epistemic state transition matrix (legal vs illegal upgrades)
- Rejection of MODEL_INFERENCE → VERIFIED
- TaskModel refuses missing success_criteria
- WorldModel preserves hidden variables as non-point values
- SelfModel correctly reports foundation-only capabilities
- RuleSpace marks rules with correct mutability

### Integration

- Meta-Controller can invoke each engine in sequence
- Telemetry emitted for every call
- Resource ceilings still enforced
- Provenance chains remain intact across engines

### Adversarial (before VERIFIED)

- Attempts to force silent epistemic upgrade
- Injection of contradictory claims
- Over-claim of SelfModel reliability

### Reproduction

- Every promoted component must have a ReproducibilityRecord

---

## 11. DELIVERABLES FOR v0.2.0-epistemic-modeling

1. This specification (frozen)
2. JSON schemas under `spec/phase1/`
3. Implementation under `runtime/epistemic/`, `runtime/world/`, `runtime/self/`, plus Task Model & Rule-Space modules
4. Unit + integration tests
5. Updated Gap Matrix
6. ChangeControlRecord linking foundation → Phase 1
7. New freeze document `docs/phase1/PHASE1_RELEASE.md`
8. Tag `v0.2.0-epistemic-modeling`

---

## 12. EXPLICIT OUT-OF-SCOPE FOR PHASE 1

- Causal Engine, Counterfactual Engine, Attractor Engine
- Value-of-Information / Active Experiment
- Capability Gap / Compiler / Graph / Mutation
- Domain Forge, Vow Compiler
- World Simulator, Intervention, Sandbox
- Verification Engine, Red Team, Verifier-of-Verifiers
- Full Master Solving Loop execution
- Any claim of task solution quality

These remain NOT_DESIGNED until later phase specifications are written and frozen.

---

## 13. CHANGE CONTROL ENTRY (template)

```
ChangeControlRecord
    previous_version    : 0.1.0-foundation
    new_version         : 0.2.0-epistemic-modeling
    reason              : Implement first cognitive modeling layer under Core governance
    expected_gain       : Explicit epistemic, task, world, self, and rule models
    expected_risk       : Low (no execution or irreversible actions)
    test_plan           : See §10 of this document
    rollback_plan       : Revert to v0.1.0-foundation tag; Gap Matrix restored from foundation snapshot
```

---

**END OF PHASE 1 SPECIFICATION**

This document is the authoritative specification for the Epistemic & Modeling Core.  
Implementation may begin only after this document is accepted as SPECIFIED and a ChangeControlRecord is recorded.
