# Phase 1 Claim Discipline Statements

**Parent rules**: Canonical §62 + foundation ClaimDiscipline.

## Allowed claims after Phase 1 implementation (once tests pass)

| Component            | Highest allowable claim (after TESTED) | After VERIFIED |
|----------------------|----------------------------------------|----------------|
| Epistemic Engine     | TEST / INTEGRATED                      | VERIFIED       |
| Task Model           | TEST / INTEGRATED                      | VERIFIED       |
| World Model          | TEST / INTEGRATED                      | VERIFIED       |
| Self Model           | TEST / INTEGRATED                      | VERIFIED       |
| Rule-Space Compiler  | TEST / INTEGRATED                      | VERIFIED       |
| ModelingResult       | “Structured models produced”           | —              |

## Forbidden claims (still)

- “The system can solve tasks”
- “World model is correct / verified against reality” (unless independent verification evidence + reproduction exist)
- “Self-model reliability is calibrated” (until calibration_history is populated by real runs)
- “Epistemic state VERIFIED” produced solely from model inference
- Any claim that unknowns have been eliminated without evidence

## Safe status phrases (examples)

- “Epistemic Engine: Implemented; verification pending.”
- “Task Model: Tested; adversarial verification pending.”
- “World Model: Scaffolded; implementation incomplete.”
- “Phase 1 complete: structured models available; no task solutions claimed.”
