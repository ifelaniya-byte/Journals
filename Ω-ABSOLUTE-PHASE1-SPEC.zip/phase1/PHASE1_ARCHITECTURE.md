# Phase 1 Architecture Addendum

**Parent**: docs/phase1/PHASE1_EPISTEMIC_MODELING.md  
**Foundation**: docs/ARCHITECTURE.md + docs/Ω-ABSOLUTE.md §3

## Placement under the existing graph

```
IMMUTABLE Ω CORE
        │
        ▼
  META-CONTROLLER  (still SCAFFOLDED; gains new invoke targets)
        │
        ├──────────────────────────────┐
        ▼                              ▼
  TASK MODEL ◄──── EPISTEMIC ENGINE ──► WORLD MODEL
        │                │                   │
        │                ▼                   │
        │           SELF MODEL               │
        │                │                   │
        └────────────────┼───────────────────┘
                         ▼
                  RULE-SPACE COMPILER
                         │
                         ▼
              ModelingResult (structured)
                         │
                         ▼
              (future phases: Causal → … → Verification)
```

## Data flow for a single task

1. Raw task enters Meta-Controller.
2. Meta-Controller invokes Epistemic Engine on all embedded propositions.
3. Epistemic Engine returns ClaimRecords (unknowns remain UNKNOWN/HYPOTHESIZED).
4. Task Model is constructed; unknowns are attached explicitly.
5. World Model is built from observations + priors + inferences (competing models allowed).
6. Self Model is consulted for capability/reliability gaps.
7. Rule-Space Compiler produces the rule set with mutability and confidence.
8. ModelingResult is returned. No execution occurs.

## Resource & safety coupling

- Every engine call is wrapped by ResourceTracker.
- Core resource ceilings remain hard limits.
- Irreversible actions remain forbidden without authorization (none are introduced in Phase 1).
- ClaimDiscipline is consulted before any ClaimRecord of elevated state is emitted.
