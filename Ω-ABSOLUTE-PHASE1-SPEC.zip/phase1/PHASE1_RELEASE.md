# Phase 1 Release Record — Epistemic & Modeling Core

**Target tag**: `v0.2.0-epistemic-modeling`  
**Current status of this document**: SPECIFIED only (implementation has not begun)  
**Parent**: `v0.1.0-foundation`

## When this release may be declared

Only after:

1. PHASE1_EPISTEMIC_MODELING.md has been accepted.
2. ChangeControlRecord moved to APPLIED.
3. All engines implemented and unit+integration tests passed.
4. Adversarial tests passed for any component marked VERIFIED.
5. Gap Matrix updated and committed.
6. ReproducibilityRecords exist for promoted components.
7. This file is updated with actual test results and commit hash.

Until then the only valid claim is:

> “Phase 1 is fully specified. Implementation pending.”

## Non-claims that remain in force

- No task solutions.
- No causal / counterfactual / verification machinery.
- No automatic promotion of any Phase-1 engine to PROMOTED without the full gate.
