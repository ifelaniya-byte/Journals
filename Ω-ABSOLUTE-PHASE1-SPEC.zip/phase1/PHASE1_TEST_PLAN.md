# Phase 1 Test Plan

**Specification**: docs/phase1/PHASE1_EPISTEMIC_MODELING.md §10  
**Required before any component may leave TESTED toward VERIFIED/PROMOTED.**

## 1. Unit Tests (mandatory)

### Epistemic Engine
- Legal state transitions succeed; illegal upgrades (e.g. HYPOTHESIZED → VERIFIED without evidence) raise.
- MODEL_INFERENCE provenance cannot produce VERIFIED.
- Contradictions are recorded, never deleted.
- STALE marking works on age and on stronger contrary claims.
- Provenance chain is preserved on reclassify.

### Task Model
- Construction fails if success_criteria is empty.
- Unknowns appear as ClaimRecords with state UNKNOWN or HYPOTHESIZED.
- Subgoal / dependency graphs are produced.
- Reversibility class is mandatory.

### World Model
- Hidden variables remain distributions or UNKNOWN; never silently collapsed.
- Competing models can co-exist.
- Epistemic state of the model as a whole is tracked.

### Self Model
- Bootstrap reports only foundation capabilities.
- Reliability queries return HYPOTHESIZED estimates until calibrated.
- Failure and calibration events append correctly.

### Rule-Space
- Rules carry mutability and confidence.
- Conflicts are detected and reported.

## 2. Integration Tests
- Meta-Controller can sequence: Epistemic → Task → World → Self → RuleSpace.
- Telemetry events emitted for every call.
- Resource ceilings still enforced under load.
- Full provenance chain from raw task to ModelingResult.

## 3. Adversarial Tests (required for VERIFIED)
- Attempted silent epistemic upgrade.
- Injection of contradictory high-confidence claims.
- SelfModel over-claim of reliability.
- TaskModel that tries to treat unknowns as known.

## 4. Reproduction
- Every component advanced to VERIFIED or PROMOTED must have a ReproducibilityRecord with status REPRODUCED.

## 5. Exit Criteria for v0.2.0
- All unit + integration tests pass.
- Adversarial suite passes for any component claiming VERIFIED.
- Gap Matrix updated and committed.
- ChangeControlRecord applied.
- PHASE1_RELEASE.md written and tagged.
