# Gap Matrix — Phase 1 Target States

This is the **target** matrix after successful completion of v0.2.0-epistemic-modeling.
It is not yet the live state. Live state remains the foundation matrix until implementation and tests succeed.

| Component                    | Current (foundation) | Target after Phase 1     | Canonical Section |
|-----------------------------|----------------------|--------------------------|-------------------|
| omega.core                  | VERIFIED             | VERIFIED (unchanged)     | §4                |
| omega.governance.*          | IMPLEMENTED          | IMPLEMENTED              | §58–62            |
| omega.telemetry             | IMPLEMENTED          | IMPLEMENTED              | §57               |
| omega.meta_controller       | SCAFFOLDED           | SCAFFOLDED → INTEGRATED* | §5                |
| omega.epistemic             | NOT_DESIGNED         | TESTED (or VERIFIED)     | §7                |
| omega.task_model            | NOT_DESIGNED         | TESTED (or VERIFIED)     | §6                |
| omega.world_model           | NOT_DESIGNED         | TESTED (or VERIFIED)     | §8                |
| omega.self_model            | NOT_DESIGNED         | TESTED (or VERIFIED)     | §9                |
| omega.rule_space            | NOT_DESIGNED         | TESTED (or VERIFIED)     | §10               |
| omega.verification          | NOT_DESIGNED         | NOT_DESIGNED             | §30               |
| omega.red_team              | NOT_DESIGNED         | NOT_DESIGNED             | §31               |
| omega.causal / etc.         | NOT_DESIGNED         | NOT_DESIGNED             | later             |

\* Meta-Controller gains new invoke targets and integration tests; full architecture-search behaviour remains future work.

**Promotion to PROMOTED** for any Phase-1 engine still requires the full gate (UNIT_TEST, ABLATION, ADVERSARIAL, REGRESSION, RESOURCE, REPRODUCTION, TRANSFER) even after VERIFIED.
