# Phase 4 — Simulation / Intervention / Sandbox
Status: SPECIFIED
Target: v0.5.0-simulation-intervention
See PHASE4_SIMULATION_INTERVENTION.md
