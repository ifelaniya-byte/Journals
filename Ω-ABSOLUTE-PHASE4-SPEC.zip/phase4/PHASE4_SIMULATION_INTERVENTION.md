# Ω-ABSOLUTE — Phase 4 Specification
## Simulation, Intervention, Reversibility & Sandbox

**Document status**: SPECIFIED (not yet implemented)  
**Target release**: v0.5.0-simulation-intervention  
**Canonical sections**: §§26–29  
**Parent**: Phases 0–3

---

## 0. PURPOSE

Phase 4 enables safe preview and selection of actions before any consequential execution.

Systems:

- World Simulator (§26)
- Intervention Engine (§27)
- Reversibility Engine (§28)
- Sandbox (§29)

**Non-claims**:
- Simulation outputs are never treated as observed reality (INVARIANT_002).
- Sandbox success is not proof of real-world correctness.
- Irreversible actions still require explicit authorization (Core safety boundary).

---

## 1. WORLD SIMULATOR (§26)

```
WORLD_MODEL → SIMULATION → POLICY_COMPARISON → POLICY_SELECTION
```

- Simulation error is tracked.
- Multiple policies can be compared under the same simulated dynamics.
- Output always carries `origin: SIMULATED`.

---

## 2. INTERVENTION ENGINE (§27)

Candidate interventions evaluated by:

- expected_gain
- causal_effect
- uncertainty
- risk
- reversibility
- cost
- verification_cost
- downstream_effects

Preference for reversible interventions when expected value is comparable.

---

## 3. REVERSIBILITY ENGINE (§28)

Action classes:

```
REVERSIBLE
PARTIALLY_REVERSIBLE
IRREVERSIBLE
```

Preferred pipeline when feasible:

```
simulation → sandbox → reversible_test → verified_intervention → irreversible_action
```

---

## 4. SANDBOX (§29)

Potentially destructive actions tested in a sandbox first.

```
SIMULATOR → SANDBOX → VERIFICATION → REAL_ENVIRONMENT
```

Sandbox is an isolation boundary, not a correctness proof.

---

## 5. INTEGRATION FLOW

```
CapabilityMachineryResult
  → generate candidate interventions
  → simulate each (World Simulator)
  → score by Intervention Engine (gain, risk, reversibility…)
  → prefer reversible paths
  → optionally execute inside Sandbox
  → SimulationInterventionResult
```

Real-environment irreversible execution remains gated by Core authorization and later Verification phase.

---

## 6. SCHEMAS (spec/phase4/)

- simulation_run.schema.json
- intervention_candidate.schema.json
- reversibility_assessment.schema.json
- sandbox_run.schema.json
- simulation_intervention_result.schema.json

---

## 7. INVARIANTS

- 002 Simulation ≠ observation
- 019 Counterfactual/simulated ≠ observed
- Core irreversible-action policy remains absolute

---

## 8. TEST PLAN (high level)

- Every simulation result is flagged SIMULATED.
- Reversibility class is attached to every candidate.
- Sandbox isolation holds (no leakage to real side-effects in tests).
- Resource ceilings respected under multi-policy simulation.
- Preference ordering favors reversible options when values are close.

---

## 9. OUT OF SCOPE

Verification hierarchy proper, Red Team, failure diagnosis loops, capability promotion, Master Solving Loop closure.

**END OF PHASE 4 SPECIFICATION**
