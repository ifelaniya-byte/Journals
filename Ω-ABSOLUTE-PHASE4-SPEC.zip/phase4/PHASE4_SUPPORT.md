# Phase 4 Support Documents

## Architecture placement
CapabilityMachineryResult → Intervention candidates → World Simulator → Reversibility scoring → Sandbox (optional) → SimulationInterventionResult.

## Change Control (template)
- previous: 0.4.0-capability
- new: 0.5.0-simulation-intervention
- risk: Medium (simulation fidelity issues; still no unauthorized irreversible action)
- rollback: revert to previous tag

## Claim Discipline
Allowed: “Interventions simulated and ranked; all results labeled SIMULATED; reversible paths preferred.”
Forbidden: treating simulation/sandbox success as real-world proof; unauthorized irreversible actions.

## Release gate (v0.5.0)
Simulation results always flagged; reversibility enforced; sandbox isolation tested; ceilings held; Gap Matrix updated.
