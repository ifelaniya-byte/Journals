# Phase 3 Support Documents

## Architecture placement
CausalTemporalResult → Capability Gap → Graph/Compiler → Architecture Search → Solver Population → Domain Forge → Vows → CapabilityMachineryResult.

## Change Control (template)
- previous: 0.3.0-causal-temporal
- new: 0.4.0-capability
- risk: Medium (search over architectures, but Core excluded)
- rollback: revert + discard capability runtime modules

## Claim Discipline
Allowed: “Capability gaps identified; candidate architectures and solver populations generated; no capability auto-promoted.”
Forbidden: majority vote as proof; Core modification; promotion without full §47 gate.

## Release gate (v0.4.0)
Tests pass; architecture search never touches Core; promotion path still blocked without evidence; Gap Matrix updated.
