# Ω-ABSOLUTE — Phase 3 Specification
## Capability Machinery

**Document status**: SPECIFIED (not yet implemented)  
**Target release**: v0.4.0-capability  
**Canonical sections**: §§18–25, §23  
**Parent**: Phases 0–2

---

## 0. PURPOSE

Phase 3 turns “what capabilities do we need?” into a first-class, searchable, composable, evolvable graph of executable machinery.

Engines / systems:

- Capability Gap Engine (§18)
- Capability Graph (§19)
- Capability Compiler (§20)
- Cognitive Architecture Search (§21)
- Solver Population (§22)
- Test-Time Compute policy (§23)
- Domain Forge (§24)
- Vow / Constraint Compiler (§25)

**Non-claims**:
- No automatic promotion of new capabilities without the full gate (§47).
- Architecture search never includes the Immutable Ω Core (INVARIANT_013).
- Majority vote among solvers is evidence, never proof (INVARIANT_017).

---

## 1. CAPABILITY GAP ENGINE (§18)

```
required_capabilities
available_capabilities
missing_capabilities
```

For each gap choose: RETRIEVE | COMPOSE | ADAPT | MUTATE | SYNTHESIZE | INVENT | DELEGATE | EXPERIMENTALLY_DISCOVER.

---

## 2. CAPABILITY GRAPH (§19)

Every validated capability is a node with relationships:

REQUIRES, IMPROVES, CONFLICTS_WITH, SPECIALIZES, GENERALIZES, COMPOSES_WITH, DEPENDS_ON, TRANSFERS_TO

Metadata: performance, cost, reliability, failure_rate, transferability, provenance, test_coverage, confidence, version.

---

## 3. CAPABILITY COMPILER (§20)

A capability is executable machinery:

```
inputs → operations → state → tools → constraints → verification → termination
```

Capabilities are composable (e.g. RETRIEVAL + CAUSAL_ANALYSIS + SIMULATION + RED_TEAM + VERIFICATION).

---

## 4. COGNITIVE ARCHITECTURE SEARCH (§21)

Search over solver architectures, e.g.:

- retrieve → reason → answer
- retrieve → simulate → reason → verify
- causal_model → experiment → intervention → red_team → verify

Architecture itself is a searchable object. Selection is empirical when feasible.

---

## 5. SOLVER POPULATION (§22)

For difficult tasks, multiple independently configured solvers (causal, symbolic, empirical, retrieval, optimization, decomposition, simulation, search, adversarial, hybrid).

Agreement = evidence; independent verification = stronger evidence.

---

## 6. TEST-TIME COMPUTE (§23)

Adaptive policy:

- low difficulty → low compute
- high uncertainty → information acquisition
- high consequence → redundancy + verification
- extreme → architecture search + population + simulation + adversarial verification

Allocation by expected marginal value.

---

## 7. DOMAIN FORGE (§24)

Temporary domain environment: rules, representations, tools, constraints, simulator, verifier.  
Treated as temporary unless explicitly promoted.

---

## 8. VOW / CONSTRAINT COMPILER (§25)

Constraints become executable search restrictions, e.g.:

- ONLY_VERIFIED_SOURCES
- NO_UNTESTED_ASSUMPTIONS
- PRESERVE_INVARIANT_X
- REQUIRE_INDEPENDENT_VERIFICATION
- NO_IRREVERSIBLE_ACTION_WITHOUT_AUTHORIZATION

Prune search space before expensive execution.

---

## 9. INTEGRATION

```
CausalTemporalResult
  → Capability Gap analysis
  → retrieve / compose / invent
  → Architecture search
  → Solver population (if warranted)
  → Domain Forge (if specialized)
  → Constraint compilation
  → CapabilityMachineryResult
```

Still no final execution of irreversible actions; simulation may be requested later (Phase 4).

---

## 10. SCHEMAS (spec/phase3/)

- capability_node.schema.json (extends foundation)
- capability_gap.schema.json
- architecture_candidate.schema.json
- solver_instance.schema.json
- domain_forge.schema.json
- vow_constraint.schema.json
- capability_machinery_result.schema.json

---

## 11. KEY INVARIANTS

- 007 New capabilities compete against baselines
- 008 / 009 / 010 Promotion requires reproducibility, regression, transfer
- 013 Core outside search
- 017 Majority ≠ proof
- 020 Complexity must justify measurable gains

---

## 12. TEST PLAN (high level)

- Gap engine correctly identifies missing vs available.
- Compiler produces executable capability objects.
- Architecture search respects Core exclusion.
- Solver population never treats majority as proof.
- Vows actually prune illegal actions.
- Promotion path still blocked without full evidence.

---

## 13. OUT OF SCOPE

Full World Simulator execution, Red Team, Verifier-of-Verifiers, Continual Learning mutation loops, Master Loop closure.

**END OF PHASE 3 SPECIFICATION**
