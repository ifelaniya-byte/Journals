# Phase 3 — Capability Machinery
Status: SPECIFIED
Target: v0.4.0-capability
See PHASE3_CAPABILITY_MACHINERY.md
