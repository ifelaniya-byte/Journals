# Phase 2 Support Documents

## Architecture placement
After Phase-1 ModelingResult → Causal / Hidden / Temporal / Counterfactual / VoI / Experiment → CausalTemporalResult.

## Change Control (template)
- previous: 0.2.0-epistemic-modeling
- new: 0.3.0-causal-temporal
- risk: Low–medium (no irreversible execution)
- rollback: revert to previous tag

## Claim Discipline
Allowed after tests: “Causal/temporal/counterfactual models produced; all counterfactuals labeled SIMULATED.”
Forbidden: treating any counterfactual or simulation as observed fact; claiming task solutions.

## Release gate (v0.3.0)
All unit/integration tests pass; adversarial checks on silent simulation→observation upgrades; Gap Matrix updated; ChangeControl APPLIED.
