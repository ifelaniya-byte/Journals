# Ω-ABSOLUTE — Phase 2 Specification
## Causal, Temporal & Counterfactual Core

**Document status**: SPECIFIED (not yet implemented)  
**Parent releases**: v0.1.0-foundation + Phase 1 (Epistemic & Modeling)  
**Target release**: v0.3.0-causal-temporal  
**Canonical parent**: docs/Ω-ABSOLUTE.md §§11–17  
**Governing Core**: Immutable Ω Core (INVARIANT_013)

---

## 0. PURPOSE

Phase 2 adds the ability to reason about **mechanisms, hidden state, time, interventions, and alternative futures** on top of the models produced by Phase 1.

Engines specified here:

- Causal Engine (§11)
- Hidden-State Engine (§12)
- Temporal Engine (§13)
- Attractor / Basin Engine (§14)
- Counterfactual Engine (§15)
- Value-of-Information Engine (§16)
- Active Experiment Engine (§17)

**Non-claims**:
- No task solutions.
- No capability synthesis, verification hierarchy, or irreversible real-world execution.
- Counterfactual outputs are always labeled simulated/inferred (INVARIANT_019).
- Simulation remains distinguishable from observation (INVARIANT_002).

---

## 1. DEPENDENCIES

Must have Phase 1 models (Task, World, Self, Epistemic, Rule-Space) available.  
All operations remain under Meta-Controller + Core ceilings + ClaimDiscipline + Provenance.

---

## 2. CAUSAL ENGINE (§11)

**Purpose**: Seek mechanisms, not merely correlations.

```
CAUSE → MECHANISM → EFFECT
```

Interventional model:
```
INTERVENTION → STATE CHANGE → OBSERVATION → MODEL UPDATE
```

Must distinguish:
- correlation
- inferred causation
- experimentally supported causation
- hypothetical causation

**Key types**:
- CausalLink (cause, mechanism, effect, strength, epistemic_state, provenance)
- InterventionRecord
- CausalGraph (nodes = variables/entities, edges = CausalLinks)

**Interface (conceptual)**:
```
causal.infer(world_model, observations) → CausalGraph
causal.intervene(graph, intervention) → predicted_effects
causal.distinguish(link) → causation_class
```

---

## 3. HIDDEN-STATE ENGINE (§12)

When the complete world state cannot be observed:

```
observations + history + world_model + prior beliefs
    → probability distribution over hidden states
```

Rules:
- Uncertainty is preserved; false certainty is forbidden.
- Output is a distribution or explicit UNKNOWN set, never a silent point estimate.

**Interface**:
```
hidden.estimate(world_model, history) → HiddenStateDistribution
hidden.update(distribution, new_observation) → HiddenStateDistribution
```

---

## 4. TEMPORAL ENGINE (§13)

Actions evaluated across horizons:

- immediate
- short_term
- medium_term
- long_term
- second_order
- third_order

Uses hierarchical abstractions when flat search is intractable.

**Interface**:
```
temporal.project(state, action, horizons) → TemporalProjection
temporal.abstract(plan, level) → AbstractPlan
```

---

## 5. ATTRACTOR / BASIN ENGINE (§14)

Identify regions of state space toward which trajectories converge.

```
initial_state → trajectories → attractor basins
```

Objective: find interventions that move the system from undesirable to desirable basins.  
Treated as search/optimization, not a claim that every real system has clean mathematical attractors.

---

## 6. COUNTERFACTUAL ENGINE (§15)

For candidate actions:

```
CURRENT_WORLD
  ├── ACTION_A → FUTURE_A
  ├── ACTION_B → FUTURE_B
  └── …
```

Each branch carries: expected_outcome, uncertainty, cost, risk, reversibility, downstream_effects, verification_cost.

**Mandatory label**: every counterfactual output is marked SIMULATED / INFERRED (never OBSERVED).

---

## 7. VALUE-OF-INFORMATION ENGINE (§16)

When uncertainty is material, ask:

> “What information would most improve the decision?”

Candidate information actions: search, retrieval, observation, tool_call, experiment, simulation, expert_query, additional_solver, verification.

Selection by: expected_information_gain, cost, latency, risk, reversibility, downstream_value.

---

## 8. ACTIVE EXPERIMENT ENGINE (§17)

Given competing hypotheses H1…Hn, generate candidate experiments ranked by expected discrimination, information gain, cost, risk, reversibility, feasibility.

---

## 9. INTEGRATION FLOW (Phase 1 → Phase 2)

```
ModelingResult (Phase 1)
  → CausalGraph + HiddenState
  → Temporal projections
  → Counterfactual branches for candidate actions
  → VoI ranking of information actions
  → optional Experiment design
  → CausalTemporalResult (still no execution)
```

---

## 10. NEW SCHEMAS (spec/phase2/)

- causal_link.schema.json / causal_graph.schema.json
- hidden_state.schema.json
- temporal_projection.schema.json
- counterfactual_branch.schema.json
- voi_query.schema.json
- experiment_design.schema.json
- causal_temporal_result.schema.json

---

## 11. INVARIANTS EMPHASIZED

| ID  | Rule |
|-----|------|
| 002 | Simulation ≠ observation |
| 003 | Hypothesis ≠ fact |
| 019 | Counterfactual outputs ≠ observations |
| 001 | Unknown remains distinguishable |

---

## 12. TEST PLAN (minimum)

- Causal class distinctions enforced.
- Hidden-state never collapses silently.
- Counterfactual results always carry SIMULATED flag.
- VoI ranking respects cost/risk.
- Resource ceilings still held.
- Provenance intact across engines.

---

## 13. OUT OF SCOPE

Capability synthesis, Domain Forge, Simulation-for-execution, Verification hierarchy, Master Solving Loop execution, any irreversible action.

---

## 14. CHANGE CONTROL (template)

```
previous_version : 0.2.0-epistemic-modeling (or foundation if Phase 1 impl pending)
new_version      : 0.3.0-causal-temporal
reason           : Add causal, temporal, counterfactual, and information-value reasoning
expected_risk    : Low–medium (still no real-world execution)
rollback_plan    : Revert to previous tag; discard phase2 runtime modules
```

**END OF PHASE 2 SPECIFICATION**
