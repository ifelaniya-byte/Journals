# Phase 6 Support

**Change Control**: previous 0.6.0 → new 0.7.0-failure-memory-evolution  
**Claim Discipline**: “Failures classified and repaired; promotion only with full gate; Core never rewritten by continual learning; rollback available.”  
**Release gate**: failure taxonomy coverage, promotion blocking tests, rollback restoration tests, Gap Matrix updated.
