# Ω-ABSOLUTE — Phase 6 Specification
## Failure, Memory & Evolution

**Document status**: SPECIFIED (not yet implemented)  
**Target release**: v0.7.0-failure-memory-evolution  
**Canonical sections**: §§36–48, 53–54  
**Parent**: Phases 0–5

---

## 0. PURPOSE

Phase 6 closes the learning and safety-evolution loop: diagnose failures, remember them, repair, test, promote or roll back, and keep the governance kernel untouched.

Systems:

- Failure Taxonomy (§36)
- Causal Failure Repair (§37)
- Failure Memory (§38)
- Memory Architecture — Episodic / Semantic / Procedural / Counterfactual (§39)
- Continual Learning (§40) — never rewrites Core
- Capability Mutation (§41)
- Ablation (§42)
- Adversarial / Transfer / Resource / Reproduction tests (§43–46)
- Capability Promotion Gate (operational) (§47)
- Capability Decay (§48)
- Versioned Self (§53)
- Rollback (§54)

---

## 1. FAILURE TAXONOMY (§36)

Canonical types:

```
PERCEPTION_FAILURE, MODEL_FAILURE, MEMORY_FAILURE, RULE_FAILURE,
CAUSAL_FAILURE, PLANNING_FAILURE, CAPABILITY_FAILURE, TOOL_FAILURE,
EXECUTION_FAILURE, RESOURCE_FAILURE, COORDINATION_FAILURE,
VERIFICATION_FAILURE, SPECIFICATION_FAILURE
```

No blind retry without diagnosis.

---

## 2. CAUSAL FAILURE REPAIR (§37)

```
failure → failure_signature → root_cause_hypotheses
       → causal_diagnosis → architecture_modification → retest
```

Preferred: diagnose → repair → validate  
Forbidden: failure → retry → failure (without diagnosis).

---

## 3. FAILURE MEMORY (§38)

Store: problem_class, failure_signature, root_cause, attempted_repair, repair_result, conditions, reusable_lesson.  
Future tasks retrieve similar patterns.

---

## 4. MEMORY ARCHITECTURE (§39)

Four classes, all provenance- and confidence-bearing:

- Episodic — what happened  
- Semantic — what is currently believed  
- Procedural — how to perform operations  
- Counterfactual — what would have happened under alternatives  

---

## 5. CONTINUAL LEARNING (§40)

Experience may update memory, reliability estimates, architecture priors, solver selection, failure priors, resource estimates.

**Hard rule**: no unverified experience may rewrite the immutable governance kernel.

---

## 6. CAPABILITY MUTATION, ABLATION, TESTS (§41–46)

- Mutation generates variants that must compete against baselines.
- Ablation: FULL_SYSTEM vs SYSTEM_WITHOUT_CAPABILITY.
- Adversarial, Transfer, Resource, Reproduction tests are mandatory promotion inputs.

---

## 7. PROMOTION GATE & DECAY (§47–48)

Full sequence (already declared in Core) is now operational:

```
BASELINE → NEW_CAPABILITY → UNIT_TEST → ABLATION → ADVERSARIAL
→ REGRESSION → RESOURCE → REPRODUCTION → TRANSFER → PROMOTION
```

Decay states: ACTIVE, DEGRADING, RETEST_REQUIRED, REPAIR_REQUIRED, RETIRED.

---

## 8. VERSIONED SELF & ROLLBACK (§53–54)

Every promoted change receives a version identifier with parent, changes, reason, benchmarks, regressions, resource effect, transfer results, provenance, rollback_target.

Rollback:

```
DETECT → ISOLATE → ROLLBACK → REVERIFY → PRESERVE_FAILURE_LESSON
```

Rollback mechanism is more trusted than the subsystem being rolled back.

---

## 9. INTEGRATION

```
VerificationHierarchyResult (or any failure)
  → classify → localize → hypothesize root cause
  → repair / replan
  → regression + adversarial + reproduction tests
  → promote or rollback
  → update Failure Memory, Capability Graph, Self Model, Versioned Self
```

---

## 10. SCHEMAS (spec/phase6/)

- failure_record.schema.json
- repair_plan.schema.json
- memory_entry.schema.json (four types)
- capability_mutation.schema.json
- promotion_evidence.schema.json
- version_record.schema.json
- rollback_record.schema.json

---

## 11. KEY INVARIANTS

- 008 / 009 / 010 / 011 / 012 Promotion & rollback rules  
- 013 Core outside self-modification  
- 016 No empirical success without execution  

---

## 12. TEST PLAN (high level)

- Every failure is classified before retry.
- Repair path produces regression tests.
- Promotion blocked without full evidence set.
- Rollback restores prior version and preserves lesson.
- Continual learning never mutates Core state.

---

## 13. OUT OF SCOPE

Cross-domain transfer abstractions, meta-experimentation strategy search, Autonomous Research Loop, final Master Loop wiring, public API finalization.

**END OF PHASE 6 SPECIFICATION**
